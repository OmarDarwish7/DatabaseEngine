public class DBAppException extends Exception{
	public DBAppException() {
		
	}
	public DBAppException(String s) {
		System.out.println(s);
	}
}
